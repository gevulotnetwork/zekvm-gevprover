#ifndef CURVE_UTILS
#define CURVE_UTILS

#include <string>

namespace CurveUtils {
    std::string getCurveNameByEngine();
}

#endif
#include "zkglobals.hpp"

Goldilocks fr;
PoseidonGoldilocks poseidon;
RawFec fec;
RawFnec fnec;
Config config;
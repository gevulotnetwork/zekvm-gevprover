#include "goldilocks_cubic_extension.hpp"
#include "zhInv.hpp"
#include "starks.hpp"
#include "constant_pols_starks.hpp"
#include "c12aSteps.hpp"

void C12aSteps::step2prev_first(StepsParams &params, uint64_t i) {
}

void C12aSteps::step2prev_i(StepsParams &params, uint64_t i) {
}

void C12aSteps::step2prev_last(StepsParams &params, uint64_t i) {
}

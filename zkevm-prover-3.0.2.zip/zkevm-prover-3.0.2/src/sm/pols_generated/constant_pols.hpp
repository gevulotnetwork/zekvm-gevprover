#ifndef CONSTANT_POLS_WRAPPER_HPP
#define CONSTANT_POLS_WRAPPER_HPP

#include "main_sm/fork_6/pols_generated/constant_pols.hpp"

#endif
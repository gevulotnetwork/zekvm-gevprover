#ifndef COMMIT_POLS_WRAPPER_HPP
#define COMMIT_POLS_WRAPPER_HPP

#include "main_sm/fork_6/pols_generated/commit_pols.hpp"

#endif
#include <string>
#include <vector>

std::vector<std::string> splitParStr(std::string s);

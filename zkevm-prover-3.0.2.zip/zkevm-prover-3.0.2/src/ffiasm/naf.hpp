#include <stdint.h>

void buildNaf(uint8_t *r, uint8_t* scalar, unsigned int scalarSize);

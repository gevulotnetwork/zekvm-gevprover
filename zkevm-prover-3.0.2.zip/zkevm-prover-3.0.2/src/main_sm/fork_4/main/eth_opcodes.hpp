#ifndef ETH_OPCODES_HPP_fork_4
#define ETH_OPCODES_HPP_fork_4

#include <string>

using namespace std;

namespace fork_4
{

extern string ethOpcode[256];

void ethOpcodeInit (void);

} // namespace

#endif
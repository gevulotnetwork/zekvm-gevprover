#ifndef MAIN_EXEC_GENERATED_FAST_HPP_fork_4
#define MAIN_EXEC_GENERATED_FAST_HPP_fork_4

#include <string>
#include "main_sm/fork_4/main/main_executor.hpp"

namespace fork_4
{
void main_exec_generated_fast (fork_4::MainExecutor &mainExecutor, ProverRequest &proverRequest);
}

#endif


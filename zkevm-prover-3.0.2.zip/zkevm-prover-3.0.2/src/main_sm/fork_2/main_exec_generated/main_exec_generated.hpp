#if 0 // Generated code has been disabled in old forks

#ifndef MAIN_EXEC_GENERATED_HPP_fork_2
#define MAIN_EXEC_GENERATED_HPP_fork_2

#include <string>
#include "main_sm/fork_2/main/main_executor.hpp"
#include "main_sm/fork_2/main/main_exec_required.hpp"

namespace fork_2
{
void main_exec_generated (fork_2::MainExecutor &mainExecutor, ProverRequest &proverRequest, fork_2::MainCommitPols &pols, fork_2::MainExecRequired &required);
}

#endif

#endif

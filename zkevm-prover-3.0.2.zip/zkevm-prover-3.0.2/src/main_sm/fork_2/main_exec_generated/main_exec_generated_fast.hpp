#if 0

#ifndef MAIN_EXEC_GENERATED_FAST_HPP_fork_2
#define MAIN_EXEC_GENERATED_FAST_HPP_fork_2

#include <string>
#include "main_sm/fork_2/main/main_executor.hpp"

namespace fork_2
{
void main_exec_generated_fast (fork_2::MainExecutor &mainExecutor, ProverRequest &proverRequest);
}

#endif

#endif
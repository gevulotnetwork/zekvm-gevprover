#ifndef ETH_OPCODES_HPP_fork_2
#define ETH_OPCODES_HPP_fork_2

#include <string>

using namespace std;

namespace fork_2
{

extern string ethOpcode[256];

void ethOpcodeInit (void);

} // namespace

#endif
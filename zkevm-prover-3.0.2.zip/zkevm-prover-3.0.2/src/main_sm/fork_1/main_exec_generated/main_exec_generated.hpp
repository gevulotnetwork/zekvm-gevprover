#if 0 // Generated code has been disabled in old forks

#ifndef MAIN_EXEC_GENERATED_HPP_fork_1
#define MAIN_EXEC_GENERATED_HPP_fork_1

#include <string>
#include "main_sm/fork_1/main/main_executor.hpp"
#include "main_sm/fork_1/main/main_exec_required.hpp"

namespace fork_1
{
void main_exec_generated (fork_1::MainExecutor &mainExecutor, ProverRequest &proverRequest, fork_1::MainCommitPols &pols, fork_1::MainExecRequired &required);
}

#endif

#endif


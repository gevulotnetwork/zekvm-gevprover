#if 0 // Generated code has been disabled in old forks

#ifndef MAIN_EXEC_GENERATED_FAST_HPP_fork_1
#define MAIN_EXEC_GENERATED_FAST_HPP_fork_1

#include <string>
#include "main_sm/fork_1/main/main_executor.hpp"

namespace fork_1
{
void main_exec_generated_fast (fork_1::MainExecutor &mainExecutor, ProverRequest &proverRequest);
}

#endif

#endif


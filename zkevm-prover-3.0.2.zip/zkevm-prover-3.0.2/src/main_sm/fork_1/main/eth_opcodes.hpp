#ifndef ETH_OPCODES_HPP_fork_1
#define ETH_OPCODES_HPP_fork_1

#include <string>

using namespace std;

namespace fork_1
{

extern string ethOpcode[256];

void ethOpcodeInit (void);

} // namespace

#endif
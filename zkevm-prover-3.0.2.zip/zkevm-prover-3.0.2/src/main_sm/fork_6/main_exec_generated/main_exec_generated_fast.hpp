#ifndef MAIN_EXEC_GENERATED_FAST_HPP_fork_6
#define MAIN_EXEC_GENERATED_FAST_HPP_fork_6

#include <string>
#include "main_sm/fork_6/main/main_executor.hpp"

namespace fork_6
{
void main_exec_generated_fast (fork_6::MainExecutor &mainExecutor, ProverRequest &proverRequest);
}

#endif


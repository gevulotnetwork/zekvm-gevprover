#ifndef ETH_OPCODES_HPP_fork_3
#define ETH_OPCODES_HPP_fork_3

#include <string>

using namespace std;

namespace fork_3
{

extern string ethOpcode[256];

void ethOpcodeInit (void);

} // namespace

#endif
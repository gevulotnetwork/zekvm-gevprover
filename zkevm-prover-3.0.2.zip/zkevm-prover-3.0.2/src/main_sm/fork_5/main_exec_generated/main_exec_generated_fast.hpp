#ifndef MAIN_EXEC_GENERATED_FAST_HPP_fork_5
#define MAIN_EXEC_GENERATED_FAST_HPP_fork_5

#include <string>
#include "main_sm/fork_5/main/main_executor.hpp"

namespace fork_5
{
void main_exec_generated_fast (fork_5::MainExecutor &mainExecutor, ProverRequest &proverRequest);
}

#endif

